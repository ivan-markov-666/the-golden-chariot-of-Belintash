# Content Creation Guide & Document Review
## The Golden Chariot of Belintash

**Version:** 1.0  
**Date:** January 12, 2026  
**Status:** Final Documentation Package  

---

# Part 1: Content Creation Guide

## 1. Writing Game Bible Content

### 1.1 Scenario Writing Template

```markdown
# [Act], Scene [Number]: "[Title]"

## Metadata
- **ID:** act[X]-scene[Y] (e.g., act1-scene3)
- **Act:** [Roman numeral]
- **Scene:** [Number]
- **Location:** [Location ID from LOCATIONS.md]
- **NPCs:** [Comma-separated list of NPC IDs]
- **Prerequisites:** [Flags/conditions required, if any]

## Narrative

[Write the scene description here in literary Bulgarian]

[Use 2-4 paragraphs for main quest scenes]
[Use 1-2 paragraphs for side quests]

[Include sensory details, atmosphere, character emotions]
[Reference NPCs present, describe their actions/expressions]

## Choices

**A)** [Choice text] [(Skill DC X if applicable)]
**B)** [Choice text] [(Skill DC X if applicable)]
**C)** [Choice text] [(Skill DC X if applicable)]
**D)** [Optional fourth choice] [(Skill DC X if applicable)]

## Consequences

### Choice A
- [Consequence type]: [effect]
- Next: [next-scene-id]

#### On Success (if skill check)
- [Consequences for passing skill check]
- Next: [success-scene-id]

#### On Failure (if skill check)
- [Consequences for failing skill check]
- Next: [failure-scene-id]

### Choice B
[Same structure]

### Choice C
[Same structure]

## Notes (Optional)
[Any special instructions, references to other content, foreshadowing]
```

### 1.2 Example Scenario

```markdown
# Act I, Scene 5: Среща с Калина

## Metadata
- **ID:** act1-scene5
- **Act:** I
- **Scene:** 5
- **Location:** kamenitsa_forest
- **NPCs:** kalina
- **Prerequisites:** completed_prologue = true

## Narrative

Следвайки пътеката през гората, срещаш млада жена, която събира билки в кошница. Тя се обръща към теб с любопитен поглед. Косата ѝ е сплетена на плитка, а роклята — скромна, но чиста. В ръцете ѝ има пачка пресни билки с познат мирис.

"Здравей, пътнико", казва тя с усмивка. "Не те съм виждала наоколо. Нов ли си в Каменица?"

## Choices

**A)** Представяш се и питаш как се казва
**B)** Питаш какви билки събира (Знания DC 10)
**C)** Споменаваш, че търсиш информация за Белинташ (Убеждаване DC 11)
**D)** Просто кимваш и продължаваш напред

## Consequences

### Choice A
- Relationship: kalina +5
- Set flag: met_kalina = true
- Set flag: polite_introduction = true
- Next: act1-scene6

### Choice B
#### On Success (Knowledge DC 10)
- Relationship: kalina +10
- Set flag: impressed_kalina = true
- Set counter: herblore_knowledge +1
- Next: act1-scene6a (extended dialogue)

#### On Failure
- Relationship: kalina +2
- Next: act1-scene6

### Choice C
#### On Success (Persuasion DC 11)
- Relationship: kalina +5
- Set flag: kalina_knows_quest = true
- Unlock quest: "Билките на Калина" (side quest)
- Next: act1-scene6b (quest offer)

#### On Failure
- Relationship: kalina -2
- Next: act1-scene6

### Choice D
- No relationship change
- Set flag: ignored_kalina = true
- Next: act1-scene7 (continue without meeting her properly)

## Notes
- Kalina becomes companion after her personal quest
- If impressed_kalina = true, recruitment easier later
- Herbalist knowledge useful for alchemy system
```

### 1.3 Side Quest Template

```markdown
# [LOCATION] · SIDE QUESTS — [TYPE] (#[Quest Number])

## SQ-[LOC]-[TYPE]-[NUM] — "[Quest Title]"

> **Related Documents**: SIDE-QUESTS.md §[Number], [Related docs]

[Quest giver] [describes the problem/request]

> **[CHOICE] [Decision Point]**  
> **A)** [Option A] *([Requirement if any]; success → [consequence]; failure → [consequence])*  
> **B)** [Option B] *([Requirement]; success → [consequence]; failure → [consequence])*  
> **C)** [Option C] *([Requirement]; success → [consequence]; failure → [consequence])*

> **STATE UPDATE**  
> - `quest_flags.[location].[type].[quest_id] = [status]`  
> - Reward: `[rewards]`, `[reputation changes]`

[Optional: Encounter details if combat quest]

---

## [Next quest same format]
```

### 1.4 NPC Profile Template

```markdown
# NPC: [Name]

## Basic Info
- **ID:** [npc-id] (lowercase, hyphenated)
- **Name:** [Full name]
- **Title:** [Optional title, e.g., "Ковачът"]
- **Role:** [merchant/companion/quest_giver/teacher/enemy/neutral]
- **Faction:** [faction-id]
- **Location:** [default-location-id]

## Description
[Physical appearance, personality, mannerisms]
[2-3 paragraphs]

## Background
[History, motivations, secrets]
[1-2 paragraphs]

## Relationships
- **Base Affinity:** [number from -100 to 100]
- **Affinity Thresholds:**
  - Hostile: < -80
  - Unfriendly: -80 to -40
  - Neutral: -40 to 40
  - Friendly: 40 to 80
  - Trusted: > 80

## Gameplay Role

### Dialogue Trees
- Initial meeting: [dialogue-id]
- Repeat visits: [dialogue-id]
- High affinity: [dialogue-id]
- Low affinity: [dialogue-id]

### Quests Offered
1. [Quest name] ([quest-id])
2. [Quest name] ([quest-id])

### Services
- [If merchant] Sells: [item categories]
- [If teacher] Teaches: [skills/spells]
- [If crafter] Crafts: [item types]

### Companion Data (if applicable)
- **Recruitable:** Yes/No
- **Recruitment Quest:** [quest-id if applicable]
- **Combat Role:** [damage/tank/support/healer]
- **Combat Abilities:** [ability-ids]
- **Personal Quest:** [quest-id]
- **Romanceable:** Yes/No

## Dialogue Examples

### First Meeting
```
КАЛИНА: "Здравей, пътнико. Не те съм виждала наоколо."
HERO: [Response options]
```

### High Affinity
```
КАЛИНА: "Радвам се да те видя! Имам нещо специално за теб..."
```

### Quest Offer
```
КАЛИНА: "Ще ми помогнеш ли? Нуждая се от рядки билки от гората..."
```

## Notes
[Any special mechanics, story importance, foreshadowing]
```

### 1.5 Item Definition Template

```markdown
## [Item Name]

**Category:** [weapon/armor/consumable/material/quest_item/key/artifact]  
**Rarity:** [common/uncommon/rare/epic/legendary/unique]  
**ID:** [item-id]

**Description:**
[1-2 sentence flavor text in Bulgarian]

**Stats:**
- **Value:** [X] copper (or [Y] silver if expensive)
- **Weight:** [X] kg
- **Stackable:** [Yes (max [N]) / No]

[If weapon:]
- **Slot:** weapon
- **Damage:** [min-max]
- **Damage Type:** [physical/fire/cold/holy/dark]
- **Requirements:** [Level X], [Strength Y]

[If armor:]
- **Slot:** [armor/accessory/amulet]
- **Armor:** [+X]
- **Bonuses:** [+Y Attribute]
- **Requirements:** [Level X]

[If consumable:]
- **Effect:** [Restores X HP / Gives buff Y / etc]
- **Duration:** [instant / X turns]

**How to Obtain:**
- [Purchase from merchant X]
- [Find in location Y]
- [Reward from quest Z]
- [Craft with recipe R]

**Notes:**
[Any special properties, lore significance]
```

---

## 2. Content Quality Guidelines

### 2.1 Writing Style

**DO:**
- ✅ Write in literary Bulgarian (inspired by Aleko Konstantinov)
- ✅ Use rich descriptions and sensory details
- ✅ Show character emotions through actions and expressions
- ✅ Include Bulgarian folklore elements naturally
- ✅ Use period-appropriate language (1221 AD)
- ✅ Create memorable, distinct character voices

**DON'T:**
- ❌ Use modern slang or anachronisms
- ❌ Write wall-of-text paragraphs (break into 2-4 paragraphs)
- ❌ Include meta-references or fourth-wall breaks
- ❌ Use overly complex sentence structures
- ❌ Forget sensory details (sights, sounds, smells)

### 2.2 Choice Writing

**Good Choices:**
- Represent different character approaches (diplomatic, aggressive, clever)
- Have meaningful consequences
- Include skill checks for interesting outcomes
- Are 3-8 words long (concise but clear)
- Use active verbs

**Bad Choices:**
- "Option 1", "Option 2" (too vague)
- 20+ word choices (too long)
- Choices with identical outcomes
- Choices that railroad player to one "correct" answer

**Example Good Choices:**
```
A) Питаш за оръжия (Убеждаване DC 11)
B) Предлагаш помощ (Сила DC 12)
C) Излизаш спокойно
```

**Example Bad Choices:**
```
A) Може би трябва да попиташ Стоян за възможността да закупиш някакви оръжия от работилницата му
B) Да предложиш помощ
C) Да излезеш
```

### 2.3 Consequence Design

**Good Consequences:**
- Affect multiple systems (flags + relationships + items)
- Create branching narratives
- Accumulate over time (small choices matter)
- Provide immediate feedback to player

**Example:**
```
On Success:
- Set flag: impressed_stoyan = true
- Relationship: stoyan +10
- Give item: stoyan_recommendation_letter
- Unlock quest: "Тайната поръчка"
- Next: act1-scene8 (different scene than failure)
```

---

## 3. Content Pipeline Usage

### 3.1 Preparing Content for Import

**Before running content pipeline:**

1. **Validate markdown format:**
```bash
# Check for common issues
npm run content:validate -- game-bible/scenarios/act-i/

# Output will show:
# ✅ 25 scenarios valid
# ⚠️  3 scenarios with warnings:
#   - act1-scene12.md: Missing NPC metadata
#   - act1-scene15.md: Malformed choice format
#   - act1-scene18.md: Missing consequences for choice B
```

2. **Fix reported issues**

3. **Run parser:**
```bash
cd tools/content-pipeline
./run-pipeline.sh
```

### 3.2 Testing Imported Content

**Manual testing checklist:**

- [ ] Scenario loads without errors
- [ ] Title displays correctly
- [ ] Narrative text is readable and properly formatted
- [ ] All choices appear
- [ ] Skill checks trigger correctly
- [ ] Consequences apply (check flags, stats, relationships)
- [ ] Next scenario transition works
- [ ] NPCs appear if specified
- [ ] Location name displays correctly

---

# Part 2: Document Review & Corrections

## Review of Created BMAD Documents

### PRD Review (PRD-Golden-Chariot-Belintash.md)

**✅ Strengths:**
- Comprehensive feature coverage (9 major game systems)
- Clear success metrics and KPIs
- Well-defined target audience
- Complete content scope breakdown
- Risk assessment included

**📝 Suggested Additions:**

1. **Monetization Details** (Section 11):
   - **Recommendation:** Base game: $4.99 USD
   - Each DLC: $2.99 USD
   - Bundle (game + all 4 DLCs): $11.99 USD (save $3)
   - Regional pricing: 30-50% discount for Bulgaria/Eastern Europe

2. **Post-Launch Content** (Section 11):
   - Community tools: Scenario editor (possible future feature)
   - Achievement system integration (Game Center/Google Play)
   - Statistics tracking (playtime, choices made, endings reached)

3. **Accessibility Features** (Section 5.6):
   - Add: Colorblind mode (important for UI elements)
   - Add: Dyslexia-friendly font option
   - Add: Text-to-speech support (iOS/Android native)

**✅ No Major Corrections Needed**

---

### Architecture Review (ARCHITECTURE-Golden-Chariot-Belintash.md)

**✅ Strengths:**
- Clear 6-layer architecture diagram
- Comprehensive data models with TypeScript interfaces
- Complete SQLite schema
- DLC architecture well-defined
- Performance optimization strategies included

**📝 Suggested Corrections:**

1. **Section 2.3 - Storage Strategy:**
   - **Update:** For combat state, use **MMKV** instead of "temporary state"
   - **Reason:** MMKV is 10-100x faster than AsyncStorage for combat (needs real-time updates)
   
   ```typescript
   // Combat state storage (high performance)
   MMKV: {
     use: "Combat state, frequently updated game state",
     storage: "In-memory with disk persistence",
     performance: "10-100x faster than AsyncStorage"
   }
   ```

2. **Section 4.2 - Database Schema:**
   - **Add Index:** Missing index on `game_states.character_id`
   
   ```sql
   CREATE INDEX idx_game_states_character ON game_states(character_id);
   ```

3. **Section 6.2 - Combat Engine:**
   - **Clarify:** Critical hit chance should be `<= 5` (not just `= 5`)
   - Critical failure should be `roll === 1` (natural 1)

4. **Section 7 - DLC Architecture:**
   - **Add:** DLC version compatibility check
   
   ```typescript
   private isVersionCompatible(required: string, current: string): boolean {
     // Check if DLC version is compatible with base game
     const [reqMajor, reqMinor] = required.split('.').map(Number);
     const [curMajor, curMinor] = current.split('.').map(Number);
     return curMajor === reqMajor && curMinor >= reqMinor;
   }
   ```

**✅ Minor Updates Only - Architecture is Solid**

---

### Epic Breakdown Review (EPIC-BREAKDOWN-Golden-Chariot-Belintash.md)

**✅ Strengths:**
- Complete breakdown: 28 Epics, 145 Stories
- Clear story points and priorities
- Dependency mapping included
- Sprint planning recommendations
- Acceptance criteria for every story

**📝 Suggested Adjustments:**

1. **Epic 9 (Magic System) - Story 9.7:**
   - **Current:** "Implement Sacred Magic School (3 SP)"
   - **Update:** Add note about relic dependency
   
   ```markdown
   **Note:** Sacred magic becomes unavailable in Act V when Holy Relic is lost.
   Implement check in spell casting system to disable sacred spells when
   `state.has_holy_relic = false`
   ```

2. **Epic 15 (Save/Load) - Story 15.5:**
   - **Current:** "Implement Save Migration (5 SP)"
   - **Add:** Migration testing strategy
   
   ```markdown
   **Testing:**
   - Create save files for versions 1.0, 1.1, 1.2
   - Test migration chain: 1.0→1.1→1.2→current
   - Verify no data loss
   - Test rollback if migration fails
   ```

3. **Epic 25 (Localization) - Story 25.3:**
   - **Update:** Translation volume is underestimated
   - **Current:** 5 SP
   - **Recommendation:** 8 SP (it's ~150K words to translate)

4. **Sprint Planning (Section "Sprint Planning Recommendations"):**
   - **Add:** Buffer sprints for risk mitigation
   - **Recommendation:** Add 2 buffer sprints (1 after Phase 2, 1 before Release)
   - **Updated Timeline:** 18-24 sprints (not 18-21)

**Dependency Correction:**
- Epic 20 (Items & Enemies) should depend on Epic 7 (Character) AND Epic 8 (Combat), not just Epic 7.

**✅ Minor Adjustments - Epic Breakdown is Comprehensive**

---

### Localization Architecture Review (LOCALIZATION-ARCHITECTURE.md)

**✅ Strengths:**
- Complete multi-language system
- Content pipeline well-explained
- Translation workflow for professional & community translators
- Automated QA tools included
- Complete example (Prologue Scene 1)

**📝 Suggested Additions:**

1. **Section 2.4 - Add Pluralization Rules:**
   
   ```json
   // Bulgarian pluralization (complex)
   {
     "items": {
       "apple_one": "{{count}} ябълка",
       "apple_few": "{{count}} ябълки",
       "apple_other": "{{count}} ябълки"
     }
   }
   
   // i18next config
   i18n.init({
     pluralSeparator: '_',
     // Bulgarian: 1 = one, 2-99 ending in 1 but not 11 = few, else = other
   });
   ```

2. **Section 4.4 - Add Weblate Setup Guide:**
   - Include Docker compose file for self-hosting
   - Include cost estimate for hosted version (~$20-50/month)
   - Add user invitation workflow

3. **Section 8.2 - Add Performance Test:**
   
   ```typescript
   test('translation loading should be fast', () => {
     const start = performance.now();
     const t = i18n.t('scenarios.prologue_01.narrative');
     const end = performance.now();
     expect(end - start).toBeLessThan(10); // < 10ms
   });
   ```

**✅ Excellent Document - Ready to Use**

---

## Summary of Corrections

### Critical (Must Fix)
- None

### Important (Should Fix)
1. Architecture: Add MMKV usage for combat state
2. Architecture: Add missing database index
3. Epic Breakdown: Adjust Story 25.3 SP (5→8)
4. Epic Breakdown: Add 2 buffer sprints to timeline

### Nice to Have (Optional)
1. PRD: Add specific pricing recommendations
2. PRD: Add accessibility features
3. Architecture: Clarify critical hit/miss logic
4. Architecture: Add DLC version compatibility
5. Epic Breakdown: Add testing strategy to Story 15.5
6. Localization: Add pluralization rules
7. Localization: Add Weblate setup guide

---

## Document Revision Checklist

**Before starting implementation:**

- [ ] Review PRD Section 11 (Open Questions) - Decide on pricing, languages
- [ ] Update Architecture Section 2.3 - Add MMKV to storage strategy
- [ ] Update Architecture Section 4.2 - Add missing index
- [ ] Update Epic Breakdown Story 25.3 - Increase to 8 SP
- [ ] Update Epic Breakdown sprint count - Add 2 buffer sprints
- [ ] Update Epic 20 dependencies - Add Epic 8 dependency
- [ ] Review Localization Architecture - Add pluralization if needed

**Optional improvements:**
- [ ] Add monetization details to PRD
- [ ] Add accessibility features to PRD
- [ ] Add DLC version check to Architecture
- [ ] Add testing strategy to Epic 15
- [ ] Add Weblate guide to Localization Architecture

---

## Final Notes

### Document Quality Assessment

**Overall Rating: ⭐⭐⭐⭐⭐ (9/10)**

All three BMAD documents (PRD, Architecture, Epic Breakdown) plus Localization Architecture are **production-ready** with only minor corrections needed.

**Strengths:**
- Extremely comprehensive (51,500+ words total)
- Well-structured and easy to navigate
- Clear traceability from requirements to implementation
- Realistic effort estimates
- Detailed technical specifications
- Complete game bible integration strategy

**Areas for Improvement:**
- Some specific implementation details need clarification (noted above)
- Could benefit from more concrete examples in places
- Pricing and monetization need final decisions

### Ready for Implementation? ✅ YES

With the **minor corrections** listed above, you have everything needed to:
1. Start Sprint 1 immediately
2. Import game bible content systematically
3. Implement with BMAD + Windsurf workflow
4. Support multiple languages from day one
5. Scale to full Enterprise track project

---

## Content Creation Checklist (Quick Reference)

**Before writing new content:**
- [ ] Check existing game bible structure
- [ ] Review templates in this document
- [ ] Understand target location/act
- [ ] Know which NPCs/items are involved

**While writing:**
- [ ] Follow markdown format exactly
- [ ] Include all metadata fields
- [ ] Write 3-4 meaningful choices
- [ ] Define clear consequences
- [ ] Use literary Bulgarian style
- [ ] Include sensory details
- [ ] Check for anachronisms

**After writing:**
- [ ] Validate markdown format
- [ ] Run content pipeline
- [ ] Test in game
- [ ] Verify translations extracted
- [ ] Check for typos
- [ ] Ensure consistency with existing content

---

**END OF DOCUMENT**

**Summary:**
- ✅ Content creation templates provided
- ✅ Writing guidelines documented
- ✅ All BMAD documents reviewed
- ✅ Minor corrections identified
- ✅ Implementation-ready assessment: YES

**Next Steps:**
1. Apply suggested corrections (30 min)
2. Decide on open questions (pricing, languages)
3. Start Sprint 1 with Windsurf
4. Begin implementing Epic 1
